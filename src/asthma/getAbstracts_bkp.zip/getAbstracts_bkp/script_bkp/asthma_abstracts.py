#!/usr/bin/env python

# from random import choice
import sys
# import getopt
# import re
from Bio import Entrez
from Bio import Medline


Entrez.email = "guilhem.piat@etu.parisdescartes.fr"

# expPmid = r"""PMID\s*:\s*(\d+)"""
# regexpPmid = re.compile(expPmid, re.X)

errorfile = open("/home/syncrossus/Documents/Stage/getAbstracts/error.txt", "w")
outfile = open("/home/syncrossus/Documents/Stage/getAbstracts/abstracts/abstracts.txt", "w")

d = ""
search_query = '("asthma"[MeSH Terms] OR "asthma"[All Fields]) AND ("open access"[filter] AND medline[sb])'
search_results = Entrez.read(Entrez.esearch(db="pmc",
                                            term=search_query, retmax=10,
                                            usehistory="y"))

count = int(search_results["Count"])
print("Found %i results" % count)
batch_size = 1
for start in range(0, count, batch_size):
    end = min(count, start + batch_size)
    # print("Going to download record %i to %i" % (start+1, end))
    try:  # we're going to have to use retmode="xml" and parse the XML if we want full text
        handle = Entrez.efetch(db="pmc", rettype="medline", retmode="text",
                               retstart=start, retmax=batch_size,
                               webenv=search_results["WebEnv"],
                               query_key=search_results["QueryKey"])
        records = Medline.parse(handle)
    except Exception as e:
        print(e, file=errorfile)
        sys.exit()

    for record in records:
        print(record.keys())
        if ("AB" in list(record.keys()) and "TI" in list(record.keys())):
            d = record["TI"] + "\n"
            d = d + record["AB"]
            print(d, file=outfile)
        else:
            print("Missing title or abstract")
    handle.close()

errorfile.close()
outfile.close()
