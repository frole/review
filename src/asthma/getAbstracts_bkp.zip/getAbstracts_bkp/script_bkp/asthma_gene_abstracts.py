#!/usr/bin/env python

from random import choice
import sys
import getopt
import re
from Bio import Entrez
from Bio import Medline


Entrez.email = "guilhem.piat@etu.parisdescartes.fr"

expPmid = r"""PMID\s*:\s*(\d+)"""
regexpPmid = re.compile(expPmid, re.X)


# liste des genes

# asthma
genes = ["IL13, IL-13,  MGC116786, MGC116788, MGC116789", "GSDMA,FKSG9,GSDM,GSDM1,FLJ39120", "GSDMB,GSDML,PP4052 ,PRO2521", "HLA-DQA1,DAQB-109B10.1,DQ-A1,HLA-DQA"]


# exzema
# a venir

errorfile = open("/home/syncrossus/Documents/Stage/getAbstracts/error.txt", "w")
outfile = open("/home/syncrossus/Documents/Stage/getAbstracts/abstracts/abstracts.txt", "w")

for g in genes:

    gene = re.split("[,\t]", g)

    gen = re.sub(",", " OR ", g)
    gen = re.sub("\t", " OR ", gen)
    print(gen)
    d = ""
    nom_gene = re.sub(r'\\', "_", gene[0])
    search_results = Entrez.read(Entrez.esearch(db="pubmed",
                                                term=gen + " asthma", retmax=10,
                                                usehistory="y"))

    count = int(search_results["Count"])
    print("Found %i results" % count)
    batch_size = 1
    for start in range(0, count, batch_size):
        end = min(count, start + batch_size)
        # print("Going to download record %i to %i" % (start+1, end))
        try:
            handle = Entrez.efetch(db="pubmed", rettype="medline", retmode="text",
                                   retstart=start, retmax=batch_size,
                                   webenv=search_results["WebEnv"],
                                   query_key=search_results["QueryKey"])
            records = Medline.parse(handle)
        except Exception as e:
            print(e, file=errorfile)
            sys.exit()

        for record in records:
            # print(record)
            if ("AB" in list(record.keys()) and "TI" in list(record.keys())):
                d = record["TI"] + "\n"
                d = d + record["AB"]
                print(d, file=outfile)
            else:
                print("shazbot")
        handle.close()

errorfile.close()
outfile.close()
