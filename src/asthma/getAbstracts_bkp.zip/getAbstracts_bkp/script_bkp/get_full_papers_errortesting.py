from Bio import Entrez, Medline

Entrez.email = "guilhem.piat@etu.parisdescartes.fr"  # e-mail for problem reports

errorfile = open("/home/syncrossus/Documents/Stage/getAbstracts/error.txt", "w")
outfile = open("/home/syncrossus/Documents/Stage/getAbstracts/abstracts/articles.txt", "w")

# search query for open access medline articles about asthma
search_query = '("asthma"[MeSH Terms] OR "asthma"[All Fields]) AND (medline[sb])'

# getting search results for the query
search_results = Entrez.read(Entrez.esearch(db="pubmed", term=search_query, retmax=10, usehistory="y"))

# checking number of results found
count = int(search_results["Count"])
print("Found %i results" % count)


batch_size = 1
# replace 1 by count
for start in range(0, 2, batch_size):
    end = min(count, start + batch_size)
    handle = Entrez.efetch(db="pubmed", rettype="medline", retmode="text", retstart=start, retmax=batch_size, webenv=search_results["WebEnv"], query_key=search_results["QueryKey"])
    records = Medline.read(handle)
    for record in records:
        print(record)
    handle.close()


errorfile.close()
outfile.close()
